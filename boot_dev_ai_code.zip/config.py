"""
Constants that are needed as part of the program
"""

API_KEY_LOCATION = "GEMINI_API_KEY"
WORKING_DIR = "./calculator"
MAX_ITERATIONS = 20
MODEL='gemini-2.5-flash'
MAX_CHARS = 10000
TIMEOUT=30